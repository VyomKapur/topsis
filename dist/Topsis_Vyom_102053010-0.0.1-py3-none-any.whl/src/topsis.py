import pandas as pd

result_file = input("Enter output file: ")
data_file = input("Enter csv data file: ")

data = pd.read_csv(data_file, header=None)
print(data)

#apply vector normalization



#multiply weights

